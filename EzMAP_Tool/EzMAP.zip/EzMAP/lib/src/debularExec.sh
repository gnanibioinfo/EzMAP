osascript -e 'tell app "Terminal" to do script "source activate qiime2-2020.2 &&
bash ~/Desktop/EzMAP/scripts/single-end-import_deblur.sh"'