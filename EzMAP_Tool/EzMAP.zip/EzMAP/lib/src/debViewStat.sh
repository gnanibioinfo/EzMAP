osascript -e 'tell app "Terminal" to do script "source activate qiime2-2020.2 &&
bash ~/Desktop/EzMAP/scripts/single_end_view_deblur_stat.sh"'