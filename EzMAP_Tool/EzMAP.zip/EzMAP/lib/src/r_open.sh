osascript -e  'tell app "Terminal" to do script "open -na Rstudio ~/Desktop/EzMAP/Downstream/downstream.R"'



