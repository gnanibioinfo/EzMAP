echo "##### EzMAP ########"
echo "### Single-end  View Quality Plots ####"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

qiime tools view Deblur/qzv/single-end-table-deblur.qzv