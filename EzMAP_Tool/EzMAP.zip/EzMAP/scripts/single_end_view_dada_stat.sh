echo "##### EzMAP ########"
echo "### Single-end  View Quality Plots ####"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

qiime tools view DADA2/qzv/single-end-denoising-stats-dada2.qzv