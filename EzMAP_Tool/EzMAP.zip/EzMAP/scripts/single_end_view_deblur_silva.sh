echo "##### EzMAP ########"
echo "### Taxanomy Classification ####"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

qiime tools view Taxonomy/SILVA/qzv/Deblur/single-end-SILVA-taxonomy-deblur.qzv