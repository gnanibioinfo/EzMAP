echo "##### EzMAP ########"
echo "### Single-end reads Cutadaptor in Execution ####"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis


time qiime cutadapt trim-single \
--i-demultiplexed-sequences single-end-demux.qza \
--p-front CCTACGGGNGGCWGCAG \
--o-trimmed-sequences single-end-trimmed-demux.qza \
--verbose > single_end_cutadapt_log.txt


time qiime demux summarize \
  --i-data single-end-trimmed-demux.qza \
  --o-visualization single-end-trimmed-demux.qzv


