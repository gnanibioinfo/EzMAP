echo "##### EzMAP ########"
echo "#### Importing Single-end reads #####"

cd ~/Desktop/EzMAP_Analysis

mkdir EzMAP_Single_End_Read_Analysis



time qiime tools import \
  --type 'SampleData[SequencesWithQuality]' \
  --input-path Bacteria_manifest \
  --output-path EzMAP_Single_End_Read_Analysis/single-end-demux.qza \
  --input-format SingleEndFastqManifestPhred33V2


cd EzMAP_Single_End_Read_Analysis



time qiime demux summarize \
  --i-data single-end-demux.qza \
  --o-visualization single-end-demux.qzv


echo "#### Import success ####"


