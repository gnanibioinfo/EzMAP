echo "##### EzMAP ########"
echo "#### Deblur #########"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Paired_End_Read_Analysis

mkdir Phylogenetic_tree
mkdir Phylogenetic_tree/Deblur
mkdir Phylogenetic_tree/Deblur/qza


time qiime phylogeny align-to-tree-mafft-fasttree \
  --i-sequences Deblur/qza/paired-end-rep-seqs-deblur.qza \
  --o-alignment Phylogenetic_tree/Deblur/qza/paired-end-aligned-rep-seqs-deblur.qza \
  --o-masked-alignment Phylogenetic_tree/Deblur/qza/paired-end-masked-aligned-rep-seqs-deblur.qza \
  --o-tree Phylogenetic_tree/Deblur/qza/paired-end-unrooted-tree-deblur.qza \
  --o-rooted-tree Phylogenetic_tree/Deblur/qza/paired-end-rooted-tree-deblur.qza


echo "#### done ####"