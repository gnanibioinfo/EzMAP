osascript -e  'tell app "Terminal" to do script "open -na Rstudio "'



