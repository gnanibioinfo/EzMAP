echo "##### EzMAP ########"
echo "#### UNITE Taxonomy Classification  #########"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

mkdir Taxonomy
mkdir Taxonomy/UNITE
mkdir Taxonomy/UNITE/qza
mkdir Taxonomy/UNITE/qzv

time qiime feature-classifier classify-sklearn \
  --i-classifier ~/Desktop/EzMAP/src/db/silva-classifier.qza \
  --i-reads qza/DADA2/single-end-rep-seqs-dada2.qza \
  --o-classification Taxonomy/UNITE/qza/single-end-greengenes-taxonomy.qza

time qiime metadata tabulate \
  --m-input-file Taxonomy/UNITE/qza/single-end-greengenes-taxonomy.qza \
  --o-visualization Taxonomy/UNITE/qzv/single-end-greengenes-taxonomy.qzv

echo "#### done ####"
