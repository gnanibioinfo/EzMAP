echo "##### EzMAP ########"
echo "#### DADA2 #########"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

mkdir Phylogenetic_tree
mkdir Phylogenetic_tree/DADA2
mkdir Phylogenetic_tree/DADA2/qza


time qiime phylogeny align-to-tree-mafft-fasttree \
  --i-sequences DADA2/qza/single-end-rep-seqs-dada2.qza \
  --o-alignment Phylogenetic_tree/DADA2/qza/single-end-aligned-rep-seqs-dada2.qza \
  --o-masked-alignment Phylogenetic_tree/DADA2/qza/single-end-masked-aligned-rep-seqs-dada2.qza \
  --o-tree Phylogenetic_tree/DADA2/qza/single-end-unrooted-tree-dada2.qza \
  --o-rooted-tree Phylogenetic_tree/DADA2/qza/single-end-rooted-tree-dada2.qza

echo "#### done ####"



