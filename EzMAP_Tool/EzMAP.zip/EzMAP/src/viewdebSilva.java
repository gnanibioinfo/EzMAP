
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author BHAVYA
 */
public class viewdebSilva {
    public void execute () {
          
             ProcessBuilder processBuilder = new ProcessBuilder();
             
               processBuilder.command("bash", "-c", "bash ~/Desktop/EzMAP/lib/src/ViewUnite.sh" );
		try {

        Process process = processBuilder.start();

        StringBuilder output = new StringBuilder();

        BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream()));

        String line;
        while ((line = reader.readLine()) != null) {
            output.append(line + "\n");
        }

        int exitVal = process.waitFor();
        if (exitVal == 0) {
            JFrame frame = new JFrame();
            JOptionPane.showMessageDialog(frame, "EzMAP View  UNITE Taxonomy","EzMAP", JOptionPane.INFORMATION_MESSAGE );
        } else {
            //abnormal...
        }

    } catch (IOException e) {
        e.printStackTrace();
    } catch (InterruptedException e) {
        e.printStackTrace();
    }
	}
    
}
