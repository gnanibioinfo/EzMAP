if (!require(remotes)) install.packages("remotes")
remotes::install_github("yiluheihei/microbiomeMarker")


library(microbiomeMarker)


bacteria1

rank_names(bacteria) <- c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species")


colnames(tax_table(bacteria)) <- c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species")


lefse.tbl <- lefse(bacteria,class="Sample.site")


marker_table(lefse.tbl)

plot_cladogram(lefse.tbl, color = c("blue", "red"))


lefse_barplot

rank_names(bacteria)