################################################################################
box_sidebar = sidebarPanel(width = 3,
  h4('Plot Parameters'),
  fluidRow(column(width = 12,
                  div(class='col-md-7', uiOutput("box_uix_x_axis")),
                  
                  
                  
  )),
)
################################################################################

###########################################################
barplotpage = fixedPage(


    box_sidebar,   
   mainPanel(

     
      tabsetPanel(
            tabPanel("Phylum",
	              plotOutput("Phylum") %>% withSpinner(color="#0dc5c1")
		    ),
	    tabPanel("Class",
	              plotOutput("Class") %>% withSpinner(color="#0dc5c1")
		    ),
	    tabPanel("Order",
	              plotOutput("Order") %>% withSpinner(color="#0dc5c1")
		    ),
	    tabPanel("Family",
	              plotOutput("Family") %>% withSpinner(color="#0dc5c1")
		    ),
            tabPanel("Genus",
	              plotOutput("Genus") %>% withSpinner(color="#0dc5c1")
                  ),
	    tabPanel("Table",
	              textOutput("Phylum2") %>% withSpinner(color="#0dc5c1")
                  )
	    
               )

           )
)

