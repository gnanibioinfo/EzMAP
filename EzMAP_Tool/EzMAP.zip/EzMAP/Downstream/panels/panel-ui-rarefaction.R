################################################################################
rare_sidebar = sidebarPanel(width = 3,
  h4('Plot Parameters'),
  fluidRow(column(width = 12,
                  div(class='col-md-7', uiOutput("rare_uix_label")),
                  div(class='col-md-7', uiOutput("rare_uix_color")),
                  
                  
  )),
)
################################################################################

###########################################################
alphaplotpage = fluidPage(
    rare_sidebar,
   
   mainPanel(

     
      tabsetPanel(
            tabPanel("Before rarefaction",
	              plotOutput("Before")
		    ),
	    tabPanel("After rarefaction",
	              plotOutput("After")
		    ),
            tabPanel("Variables",
	              textOutput("Variable")
		    )
	    
	    
               )

           )
)