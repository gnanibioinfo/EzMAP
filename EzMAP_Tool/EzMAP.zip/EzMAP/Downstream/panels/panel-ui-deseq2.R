desq_side = sidebarPanel(
                div(class='col-md-6', 
                      selectInput(inputId="desa_select",
                              label="Select Dataset",
                              choices= c("Original", "Filtered"), 
                              selected="Original",
                              multiple=FALSE)),
 )

deseqpage = fluidPage(

desq_side,
 
   mainPanel(

     
      tabsetPanel(
            tabPanel("DESeq2",
	              dataTableOutput("OTU5") %>% withSpinner(color="#0dc5c1")
		    ),
	    tabPanel("Lefse",
	              dataTableOutput("TAX6") %>% withSpinner(color="#0dc5c1")
		    )
	   
	    
               )

           )
)

