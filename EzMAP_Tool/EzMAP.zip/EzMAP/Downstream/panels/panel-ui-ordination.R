################################################################################
# sbp of plot_ordination 
################################################################################
ordtypelist <- as.list(phyloseq::plot_ordination("list"))
names(ordtypelist) <- ordtypelist
ordtypelist = ordtypelist[which(ordtypelist %in% c("sites"))]
names(ordtypelist) <- c("Samples")



sbp_ord = sidebarPanel(
  h4("Structure"),
  fluidRow(column(
    width = 12,
    div(class="col-md-4", selectInput("ord_plot_type", "Display", ordtypelist)), 
    div(class="col-md-4", selectInput("ord_method", "Method", ordlist, selected="DCA")),
    div(class="col-md-4", uiOutput("ord_uix_dist"))
  )),
  
  
  fluidRow(column(
    width = 12,
    div(class="col-md-6", uiOutput("ord_uix_color")),
    div(class="col-md-5", uiOutput("ord_uix_shape")),
    div(class='col-md-7', uiOutput("ord_uix_label")),
    
  )),
  
  
)
################################################################################
ordpage = fluidPage(
  headerPanel("Ordination Plot"),
  fluidRow(sbp_ord,
    column(width = 8,
           div(class="col-md-12", plotOutput("ordination")),
           div(class="col-md-12", br())
  )),
  
)
################################################################################
