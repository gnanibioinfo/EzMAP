sampledata = reactive({
  get_phyloseq_data()
})


summ = reactive({
  sam_otu=NULL
  sam_data <- get_phyloseq_data()
  king<-tax_table(sam_data)[,"Rank1"] %>% unique %>%  length
  phy<-tax_table(sam_data)[,"Rank2"] %>% unique %>%  length
  class<-tax_table(sam_data)[,"Rank3"] %>% unique %>%  length
  order<-tax_table(sam_data)[,"Rank4"] %>% unique %>%  length
  family<-tax_table(sam_data)[,"Rank5"] %>% unique %>%  length
  genus<-tax_table(sam_data)[,"Rank6"] %>% unique %>%  length
  
  Classification <- c("Kingdoms:","Phylum", "Class", "Order", "Family", "Genus")
  No <- c(king,phy,class,order,family,genus)
  sam_otu <- data.frame(Classification,No)
  return(sam_otu)
  
})

output$summary <- renderDataTable({
  summ()
})



phylum = reactive ({
  data1= sampledata()
  data=NULL
  try(
    data <- data1 %>% 
      psmelt %>%
      group_by(Rank2) %>% 
      summarize(OTUn = (unique(OTU) %>% length)) %>% 
      arrange(desc(OTUn))
  )
  return(data)
})

output$phylum_otu <- renderDataTable({
  phylum()
})


class = reactive ({
  data1= sampledata()
  data=NULL
  try(
    data <- data1 %>% 
      psmelt %>%
      group_by(Rank3) %>% 
      summarize(OTUn = (unique(OTU) %>% length)) %>% 
      arrange(desc(OTUn))
  )
  return(data)
})

output$class_otu <- renderDataTable({
  class()
})

order = reactive ({
  data1= sampledata()
  data=NULL
  try(
    data <- data1 %>% 
      psmelt %>%
      group_by(Rank4) %>% 
      summarize(OTUn = (unique(OTU) %>% length)) %>% 
      arrange(desc(OTUn))
  )
  return(data)
})

output$order_otu <- renderDataTable({
  order()
})

family = reactive ({
  data1= sampledata()
  data=NULL
  try(
    data <- data1 %>% 
      psmelt %>%
      group_by(Rank5) %>% 
      summarize(OTUn = (unique(OTU) %>% length)) %>% 
      arrange(desc(OTUn))
  )
  return(data)
})

output$family_otu <- renderDataTable({
  family()
})

genus = reactive ({
  data1= sampledata()
  data=NULL
  try(
    data <- data1 %>% 
      psmelt %>%
      group_by(Rank6) %>% 
      summarize(OTUn = (unique(OTU) %>% length)) %>% 
      arrange(desc(OTUn))
  )
  return(data)
})

output$genus_otu <- renderDataTable({
  genus()
})



