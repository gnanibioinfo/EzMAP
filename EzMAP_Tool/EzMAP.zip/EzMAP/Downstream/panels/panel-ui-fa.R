fa_side = sidebarPanel(
                div(class='col-md-6', 
                      selectInput(inputId="fa_select",
                              label="Select Dataset",
                              choices= c("Original", "Filtered"), 
                              selected="Original",
                              multiple=FALSE)),
 )

fapage = fluidPage(

fa_side,
 
   mainPanel(

     
      tabsetPanel(
            tabPanel("PICRust",
	              dataTableOutput("OTU2") %>% withSpinner(color="#0dc5c1")
		    ),
	    tabPanel("Tax4Fun",
	              dataTableOutput("TAX2") %>% withSpinner(color="#0dc5c1")
		    ),
	    tabPanel("FUNGuilds",
	              dataTableOutput("META2") %>% withSpinner(color="#0dc5c1")
		    )
	    
               )

           )
)

