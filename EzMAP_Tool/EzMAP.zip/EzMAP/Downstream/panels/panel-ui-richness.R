################################################################################
# sbp of plot_richness
################################################################################
richmeasvars = c("Observed", "Chao1", "ACE", "Shannon", "Simpson", "InvSimpson", "Fisher")
sbp_rich = sidebarPanel(
  h4('Aesthetic Mapping'),
  fluidRow(column(width = 12,                  
                  div(class='col-md-6', uiOutput("rich_uix_x")),
                  div(class='col-md-6', uiOutput("rich_uix_color")),
                  div(class='col-md-5', uiOutput("rich_uix_shape")),
                  div(class='col-md-6', 
                      selectInput(inputId="measures_rich",
                              label="alpha Measures",
                              choices=richmeasvars, 
                              selected=c("Shannon", "Chao1"),
                              multiple=TRUE)),
                  div(class='col-md-7', uiOutput("rich_uix_label")),
                  
  )),
  
  fluidRow(column(width = 12,
                  
                  numericInputRow("x_axis_angle_rich", label = "X-axis label Angle",
                                  value = 90, min = 0, max = 360, step = 45, class="input-mini"),
                  
                  )),
  
)
################################################################################
## https://github.com/rstudio/shiny/wiki/Shiny-Application-Layout-Guide#grid-layouts-in-depth
richpage = fluidPage(
  headerPanel("Alpha Diversity Estimates", "windowTitle"), 
  fluidRow(
    sbp_rich,
    column(width = 8, plotOutput("richness"), offset = 0)
  ),
  
)
