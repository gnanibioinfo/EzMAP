################################################################################
# UI
################################################################################
output$box_uix_x_axis <- renderUI({
  selectInput("axis_box", 
        label = "Label",
        choices = c(list("Sample"), variables()),
        selected = "NULL")
})

################################################################################

taxonomicplots = reactive({
  get_phyloseq_data()
})

# Standardize abundances to the median sequencing depth
median_sequencing_depth = reactive({
depth=NULL
total <- median(sample_sums(taxonomicplots())) 
standf <- function(x, t=total) round(t * (x / sum(x)))
try(
depth <- transform_sample_counts(taxonomicplots(), standf)  
)
return(depth)
})


physeq_barplot = reactive({
  median_sequencing_depth()
})




phylumplot = reactive ({

plot= NULL

try(
plot <- tax_glom(physeq_barplot(), taxrank="Rank2")%>%       
transform_sample_counts(function(x)(x/sum(x))) %>%
psmelt()%>%
filter(Abundance>0.01)
)
return(plot)

})




variables = reactive({

data<-colnames(genusplot())
myvars <- data %in% c("OTU", "Abundance", "Rank1", "Rank2","Rank3","Rank4","Rank5","Rank6")
data <- data[!myvars]


})




output$Phylum2 <- renderText({
  variables()

})


classplot = reactive ({
tax_glom(physeq_barplot(), taxrank="Rank3")%>%       
transform_sample_counts(function(x)(x/sum(x))) %>%
psmelt()%>%
filter(Abundance>0.01)
})


orderplot = reactive ({
tax_glom(physeq_barplot(), taxrank="Rank4")%>%       
transform_sample_counts(function(x)(x/sum(x))) %>%
psmelt()%>%
filter(Abundance>0.01)
})

familyplot = reactive ({
tax_glom(physeq_barplot(), taxrank="Rank5")%>%       
transform_sample_counts(function(x)(x/sum(x))) %>%
psmelt()%>%
filter(Abundance>0.01)
})

genusplot = reactive ({
tax_glom(physeq_barplot(), taxrank="Rank6")%>%       
transform_sample_counts(function(x)(x/sum(x))) %>%
psmelt()%>%
filter(Abundance>0.01)
})


make_phylum_plot = reactive({
  ggplot(phylumplot(),aes_string(x =input$axis_box, y="Abundance", fill="Rank2"))+ geom_bar(stat = "identity", position = "fill"  ) +
  scale_fill_hue(l=40)+ theme_bw(base_size = 18) + xlab("")+ ylab("Relative Abundance") + 
  theme(axis.text.x = element_text(angle = 90)) +
  theme(legend.position="bottom", 
        legend.box="vertical", 
	legend.margin=margin(),
        legend.key.height = unit(0.5, 'cm'), 
        legend.key.width = unit(0.5, 'cm'), 
        legend.title = element_text(size=10), 
        legend.text = element_text(size=10)
  
  )
})

make_class_plot = reactive({
  ggplot(classplot(),aes_string(x=input$axis_box, y="Abundance", fill="Rank3"))+ geom_bar(stat = "identity", position = "fill"  ) +
  scale_fill_hue(l=40) +  theme_bw(base_size = 18) + xlab("")+ ylab("Relative Abundance") + 
  theme(axis.text.x = element_text(angle = 90)) +
  theme(legend.position="bottom", 
        legend.box="vertical", 
	legend.margin=margin(),
        legend.key.height = unit(0.3, 'cm'), 
        legend.key.width = unit(0.3, 'cm'), 
        legend.title = element_text(size=10), 
        legend.text = element_text(size=10)
  
  )
})

make_order_plot = reactive({
  ggplot(orderplot(),aes_string(x=input$axis_box, y="Abundance", fill="Rank4"))+ geom_bar(stat = "identity", position = "fill"  ) +
  scale_fill_hue(l=40) +  theme_bw(base_size = 18) + xlab("")+ ylab("Relative Abundance") + 
  theme(axis.text.x = element_text(angle = 90)) +
  theme(legend.position="bottom", 
        legend.box="vertical", 
	legend.margin=margin(),
        legend.key.height = unit(0.3, 'cm'), 
        legend.key.width = unit(0.3, 'cm'), 
        legend.title = element_text(size=10), 
        legend.text = element_text(size=10)
  
  )
})

make_family_plot = reactive({
  ggplot(familyplot(),aes_string(x=input$axis_box, y="Abundance", fill="Rank5"))+ geom_bar(stat = "identity", position = "fill"  ) +
  scale_fill_hue(l=40) +  theme_bw(base_size = 18) + xlab("")+ ylab("Relative Abundance") + 
  theme(axis.text.x = element_text(angle = 90)) +
  theme(legend.position="bottom", 
        legend.box="vertical", 
	legend.margin=margin(),
        legend.key.height = unit(0.3, 'cm'), 
        legend.key.width = unit(0.3, 'cm'), 
        legend.title = element_text(size=10), 
        legend.text = element_text(size=10)
  
  )
})

make_genus_plot = reactive({
  ggplot(genusplot(),aes_string(x=input$axis_box, y="Abundance", fill="Rank6"))+ geom_bar(stat = "identity", position = "fill"  ) +
  scale_fill_hue(l=40) +  theme_bw(base_size = 18) + xlab("")+ ylab("Relative Abundance") + 
  theme(axis.text.x = element_text(angle = 90)) +
  theme(legend.position="bottom", 
        legend.box="vertical", 
	legend.margin=margin(),
        legend.key.height = unit(0.3, 'cm'), 
        legend.key.width = unit(0.3, 'cm'), 
        legend.title = element_text(size=10), 
        legend.text = element_text(size=10)
  
  )
})



output$Phylum <- renderPlot({
  plot(make_phylum_plot())
},width=function(){300*3}, height=function(){300*2})

output$Class <- renderPlot({
  plot(make_class_plot())
},width=function(){300*3}, height=function(){300*2})

output$Order <- renderPlot({
  plot(make_order_plot())
},width=function(){300*3}, height=function(){300*2})

output$Family <- renderPlot({
  plot(make_family_plot())
},width=function(){300*3}, height=function(){300*2})

output$Genus <- renderPlot({
  plot(make_genus_plot())
},width=function(){300*3}, height=function(){300*2})



alphaplot = reactive({
p4 = NULL
  try(p4 <- plot_richness(physeq_rich(),
                          measures = c ("Observed", "Shannon")),
      silent=TRUE)
  return(p4)
})


shana = reactive({
  alphaplot()$data[alphaplot()$data$variable == "Observed", ]
})




output$Depth <- renderTable({
  sample_sums(physeq_barplot())

})

#make_shannon_plot = reactive({
#ggplot(shana(), aes(x=Sample.site, y=value, fill=Sample.site)) +
#geom_boxplot(width=0.3, outlier.shape=NA)+  geom_jitter(size=3, position = position_jitter(0.1))+
#theme_bw(base_size = 20)+ xlab("")+ ylab("Observed species")
#})


#output$Alpha <- renderPlot({
#  shiny_phyloseq_print(make_shannon_plot())
#}, width=function(){72*8}, height=function(){72*8})

