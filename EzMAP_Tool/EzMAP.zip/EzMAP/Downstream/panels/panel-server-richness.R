################################################################################
# UI
################################################################################
output$rich_uix_x <- renderUI({
  selectInput("x_rich", 
        label = "X",
        choices = c(list("samples"), vars("samples")),
        selected = "samples")
})
output$rich_uix_color <- renderUI({
  selectInput("color_rich",
              label = "Color",
              choices = c(list("samples"), vars("samples")),
              selected = "NULL")
})

################################################################################
# Alpha Diversity plot definition
################################################################################
#physeq_rich = reactive({
#  return(switch(input$uicttype_rich, Original=get_phyloseq_data(), Filtered=physeq()))
#})

color<-rownames(RColorBrewer::brewer.pal.info)

colorlist = color[which(color %in% c("Set3"))]



physeq_rich = reactive({
  physeq()
})

make_richness_plot = reactive({
  p4 = NULL
  try(p4 <- plot_richness(physeq_rich(),
                          measures = input$measures_rich),
      silent=TRUE)
  return(p4)
})
finalize_richness_plot = reactive({
  p4 = make_richness_plot()
  if(inherits(p4, "ggplot")){
    # Adjust size/alpha of points, but not error bars
    
    # x (horizontal) axis mapping
    if(!is.null(av(input$x_rich))){
      p4$mapping$x <- as.symbol(input$x_rich)
      p4 <- update_labels(p4, list(x = input$x_rich))
    }
    
    # Color mapping/palette.
    if(!is.null(av(input$color_rich))){
      p4$mapping$colour <- as.symbol(input$color_rich)
      p4 <- update_labels(p4, list(colour = input$color_rich))
      if(plyr::is.discrete(p4$data[[input$color_rich]])){
        # Discrete brewer palette mapping
        p4 <- p4 + scale_colour_brewer(palette=colorlist)
      } else {
        # Continuous brewer palette mapping
        p4 <- p4 + scale_colour_distiller(palette=colorlist) 
      }    
    }
    # Point-label mapping
    if(!is.null(av(input$label_rich))){
      p4 <- p4 + geom_text(aes_string(label=input$label_rich), 
                           size = 3,
                           vjust = 2)
    }
    p4 <- p4 + theme_bw()
    # Add the x-axis label rotation as specified by user
    p4 <- p4 + theme(axis.text.x = element_text(
      angle = input$x_axis_angle_rich,
      vjust = 0.5)
    )
    # Protect against too-many x-axis labels
    # Should be based on the aesthetic in p4 (more general)
    if(!is.null(av(input$x_rich))){
      if(plyr::is.discrete(p4$data[[input$x_rich]])){
        # Check the number of discrete classes (e.g. factor levels)
        if(length(unique(p4$data[[input$x_rich]])) > 30){
          # If number of classes is above max, set x-axis theme to blank
          p4 <- p4 + theme(axis.text.x = element_blank(),
                           axis.ticks.x = element_blank())
        } 
      }      
    }
    return(p4)
  } else {
    # If for any reason p4 is not a ggplot at this point,
    # render fail-plot rather than tinker with innards.
    return(fail_gen())
  }
})
# Render plot in panel and in downloadable file with format specified by user selection
output$richness <- renderPlot({
  shiny_phyloseq_print(finalize_richness_plot())
}, width=function(){72*8}, height=function(){72*8})
