view_side = sidebarPanel(
                div(class='col-md-6', 
                      selectInput(inputId="dataset_select",
                              label="Select Dataset",
                              choices= c("Original", "Filtered"), 
                              selected="Original",
                              multiple=FALSE)),
 )

viewpage = fluidPage(

view_side,
 
   mainPanel(

     
      tabsetPanel(
            tabPanel("OTU Table",
	              dataTableOutput("OTU") %>% withSpinner(color="#0dc5c1")
		    ),
	    tabPanel("Taxonomy Table",
	              dataTableOutput("TAX") %>% withSpinner(color="#0dc5c1")
		    ),
	    tabPanel("Metadata",
	              dataTableOutput("META") %>% withSpinner(color="#0dc5c1")
		    )
	    
               )

           )
)

