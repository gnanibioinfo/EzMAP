################################################################################
filterpage = fluidPage(
  
  
  fluidRow(
    # Sidebar Panel default is 4-column.
    sidebarPanel(

      
      
      h4('Data Pre-processing'),

      
      fluidRow(column(width=12,
                      div(class="col-md-6",
                          numericInputRow("filter_sample_sums_threshold", "Filter taxa Less than ",
                                          value=SampleSumDefault, min=0, step=1, class="col-md-12")),
                      div(class="col-md-6",
                          numericInputRow("filter_taxa_sums_threshold", "Min sample (%)",
                                          value=OTUSumDefault, min=10, step=10, class="col-md-12"))
      )),
      
      h4("Subset Taxa"),
      fluidRow(column(width=12,
                      div(class="col-md-6", uiOutput("filter_uix_subset_taxa_ranks")),
                      div(class="col-md-6", uiOutput("filter_uix_subset_taxa_select"))
      )),
      h4("Subset Samples"),
      fluidRow(column(width=12,
                      div(class="col-md-6", uiOutput("filter_uix_subset_sample_vars")),
                      div(class="col-md-6", uiOutput("filter_uix_subset_sample_select"))
      )),
      
     actionButton("actionb_filter", "Filter" ), 
    ),
    # Now the Main Panel.
    column(
      width = 8, offset = 0, 
      h4("Histograms Before and After Filtering"),
      plotOutput("filter_summary_plot"),
      h4("Data Summaries"),
      fluidRow(
        column(width = 6,
               p("Original"),
               htmlOutput('filtered_contents0')
        ),
        column(width = 6,
               p("Filtered Data:"),
               htmlOutput('filtered_contents')
      )),
      
     
    )
  ),
  
)
################################################################################
