# Data I/O page
sbp_data = sidebarPanel(
  uiOutput("phyloseqDataset"),
  h5("Upload Biom File"),
  fileInput('filebiom', "", multiple = TRUE),
  
  h5("Upload Tree File (.nwk)"),
  fileInput('treefile', "", multiple = FALSE)
)

datapage = fixedPage(
  h3("Dataset Upload and Selection"),
  sbp_data,
  column(width = 8,
    
    h4("Data Summary"),
    htmlOutput('contents'),
    
    h4("Taxonomy summary"),
    tableOutput("summary2"),
    
    

  ),
  
)
