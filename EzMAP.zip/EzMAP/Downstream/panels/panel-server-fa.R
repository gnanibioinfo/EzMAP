fatables = reactive({
  get_phyloseq_data()
})


otutable_view = reactive({
  otu_table(viewtables())
})

taxtable_view = reactive({
  tax_table(viewtables())
})

metadata_view = reactive({
  sample_data(viewtables())
})

output$OTU <- renderDataTable({
  otutable_view()
})

output$TAX <- renderDataTable({
  taxtable_view()
})

output$META <- renderDataTable({
  metadata_view()
})


