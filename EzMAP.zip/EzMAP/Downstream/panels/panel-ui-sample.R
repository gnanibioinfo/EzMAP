sample_side = sidebarPanel(
                div(class='col-md-6', 
                      selectInput(inputId="dataset_sample",
                              label="Select Dataset",
                              choices= c("Original", "Filtered"), 
                              selected="Original",
                              multiple=FALSE)),
 )

samplepage = fluidPage(

sample_side,
 
   mainPanel(

     
      tabsetPanel(
            tabPanel("Summary",
	              dataTableOutput("summary") 
		      
		    ),
	    tabPanel("Phylum",
	              dataTableOutput("phylum_otu") 
		    ),
	    tabPanel("Class",
	              dataTableOutput("class_otu") 
		    ),
	    tabPanel("Order",
	              dataTableOutput("order_otu") 
		    ),
	    tabPanel("Family",
	              dataTableOutput("family_otu") 
		    ),
	    tabPanel("Genus",
	              dataTableOutput("genus_otu") 
		    )
	    
               )

           )
)

