echo "##### EzMAP ########"
echo "#### DADA2 #########"



cp ~/Desktop/denoise_config.txt ~/Desktop/EzMAP/scripts/includes/denoise_config.txt



cd ~/Desktop/EzMAP_Analysis

DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )


infile="$DIR/includes/denoise_config.txt"

echo $infile

v2=$(head -n 1 $infile)

v3=$(sed -n '2{p;q;}' $infile)

#v4=$(sed -n '3{p;q;}' $infile)

echo "Trimming at $v2 base number in the start of each sequence"
echo "Truncating at $v3 base number"
#echo $v4 




cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

mkdir DADA2
mkdir DADA2/qza
mkdir DADA2/qzv


time qiime dada2 denoise-single \
  --i-demultiplexed-seqs single-end-trimmed-demux.qza \
  --p-trim-left $v2 \
  --p-trunc-len $v3 \
  --o-table DADA2/qza/single-end-table-dada2.qza \
  --o-representative-sequences DADA2/qza/single-end-rep-seqs-dada2.qza \
  --o-denoising-stats DADA2/qza/single-end-denoising-stats-dada2.qza


time qiime feature-table summarize \
  --i-table DADA2/qza/single-end-table-dada2.qza \
  --o-visualization DADA2/qzv/single-end-table-dada2.qzv \
  --m-sample-metadata-file ~/Desktop/EzMAP_Analysis/sample-metadata.tsv

time qiime feature-table tabulate-seqs \
  --i-data DADA2/qza/single-end-rep-seqs-dada2.qza \
  --o-visualization DADA2/qzv/single-end-rep-seqs-dada2.qzv


time qiime metadata tabulate \
  --m-input-file DADA2/qza/single-end-denoising-stats-dada2.qza \
  --o-visualization DADA2/qzv/single-end-denoising-stats-dada2.qzv

echo "#### done ####"
