echo "##### EzMAP ########"
echo "### Single-end reads Cutadaptor in Execution ####"



cp ~/Desktop/primer_config.txt ~/Desktop/EzMAP/scripts/includes/primer_config.txt



cd ~/Desktop/EzMAP_Analysis

DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )


infile="$DIR/includes/primer_config.txt"

echo $infile

v2=$(head -n 1 $infile)


echo "using the primer: $v2"


cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis


time qiime cutadapt trim-single \
--i-demultiplexed-sequences single-end-demux.qza \
--p-front $v2 \
--o-trimmed-sequences single-end-trimmed-demux.qza \
--verbose > single_end_cutadapt_log.txt


time qiime demux summarize \
  --i-data single-end-trimmed-demux.qza \
  --o-visualization single-end-trimmed-demux.qzv


