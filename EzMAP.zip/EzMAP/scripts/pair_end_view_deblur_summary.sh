echo "##### EzMAP ########"
echo "### Single-end  View Quality Plots ####"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Paired_End_Read_Analysis

qiime tools view Deblur/qzv/paired-end-table-deblur.qzv