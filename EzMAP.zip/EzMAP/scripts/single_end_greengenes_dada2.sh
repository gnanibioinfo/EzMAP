echo "##### EzMAP ########"
echo "#### Greengenes Taxonomy Classification  #########"


DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )


infile1="$DIR/includes/denoise_config.txt"

infile2="$DIR/includes/primer_config.txt"

echo $infile1

echo $infile2

v2=$(head -n 1 $infile1)

v3=$(sed -n '2{p;q;}' $infile1)

v4=$(sed -n '1{p;q;}' $infile2)


echo "p-f-primer is set to $v4"

echo "p-trunc-len is set to $v3"

echo "p-min-length is set to 100"

echo "p-max-length is set to 400" 







cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

wget \
  -O "85_otus.fasta" \
  "https://data.qiime2.org/2020.11/tutorials/training-feature-classifiers/85_otus.fasta"


wget \
  -O "85_otu_taxonomy.txt" \
  "https://data.qiime2.org/2020.11/tutorials/training-feature-classifiers/85_otu_taxonomy.txt"




time qiime tools import \
  --type 'FeatureData[Sequence]' \
  --input-path 85_otus.fasta \
  --output-path 85_otus.qza

time qiime tools import \
  --type 'FeatureData[Taxonomy]' \
  --input-format HeaderlessTSVTaxonomyFormat \
  --input-path 85_otu_taxonomy.txt \
  --output-path ref-taxonomy.qza





qiime feature-classifier extract-reads \
  --i-sequences 85_otus.qza \
  --p-f-primer $v4 \
  --p-r-primer GGACTACHVGGGTWTCTAAT \
  --p-trunc-len $v3 \
  --p-min-length 100 \
  --p-max-length 400 \
  --o-reads ref-seqs.qza




qiime feature-classifier fit-classifier-naive-bayes \
  --i-reference-reads ref-seqs.qza \
  --i-reference-taxonomy ref-taxonomy.qza \
  --o-classifier gg-13-8-99-515-806-nb-classifier.qza


cp   gg-13-8-99-515-806-nb-classifier.qza ~/Desktop/EzMAP/src/db/gg-13-8-99-515-806-nb-classifier.qza




mkdir Taxonomy
mkdir Taxonomy/Greengenes
mkdir Taxonomy/Greengenes/qza
mkdir Taxonomy/Greengenes/qzv
mkdir Taxonomy/Greengenes/qza/DADA2
mkdir Taxonomy/Greengenes/qzv/DADA2

time qiime feature-classifier classify-sklearn \
  --i-classifier ~/Desktop/EzMAP/src/db/gg-13-8-99-515-806-nb-classifier.qza \
  --i-reads DADA2/qza/single-end-rep-seqs-dada2.qza \
  --o-classification Taxonomy/Greengenes/qza/DADA2/single-end-greengenes-taxonomy-dada2.qza

time qiime metadata tabulate \
  --m-input-file Taxonomy/Greengenes/qza/DADA2/single-end-greengenes-taxonomy-dada2.qza \
  --o-visualization Taxonomy/Greengenes/qzv/DADA2/single-end-greengenes-taxonomy-dada2.qzv



qiime tools export --input-path Taxonomy/Greengenes/qza/DADA2/single-end-greengenes-taxonomy-dada2.qza \
--output-path Taxonomy/Greengenes/qzv/DADA2/Export

qiime tools export --input-path DADA2/qza/single-end-table-dada2.qza \
--output-path Taxonomy/Greengenes/qzv/DADA2/Export

biom add-metadata -i Taxonomy/Greengenes/qzv/DADA2/Export/feature-table.biom -o Taxonomy/Greengenes/qzv/DADA2/Export/feature-table-with-taxonomy.biom \
--observation-metadata-fp Taxonomy/Greengenes/qzv/DADA2/Export/taxonomy.tsv --observation-header OTUID,taxonomy --sc-separated taxonomy


biom add-metadata -i Taxonomy/Greengenes/qzv/DADA2/Export/feature-table-with-taxonomy.biom -o Taxonomy/Greengenes/qzv/DADA2/Export/feature-table-with-taxonomy-meta.biom \
--sample-metadata-fp ~/Desktop/EzMAP_Analysis/sample-metadata.tsv --sample-header sample-id,sample-site,cultivar,compartment

cp Taxonomy/Greengenes/qzv/DADA2/Export/feature-table-with-taxonomy-meta.biom ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis/table-w-tax-meta.biom


echo "#### done ####"