eecho "##### EzMAP ########"
echo "#### Greengenes Taxonomy Classification  #########"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

wget \
  -O "85_otus.fasta" \
  "https://data.qiime2.org/2020.11/tutorials/training-feature-classifiers/85_otus.fasta"


wget \
  -O "85_otu_taxonomy.txt" \
  "https://data.qiime2.org/2020.11/tutorials/training-feature-classifiers/85_otu_taxonomy.txt"



time qiime tools import \
  --type 'FeatureData[Sequence]' \
  --input-path 85_otus.fasta \
  --output-path 85_otus.qza

Time qiime tools import \
  --type 'FeatureData[Taxonomy]' \
  --input-format HeaderlessTSVTaxonomyFormat \
  --input-path 85_otu_taxonomy.txt \
  --output-path ref-taxonomy.qza


qiime feature-classifier extract-reads \
  --i-sequences 85_otus.qza \
  --p-f-primer GTGCCAGCMGCCGCGGTAA \
  --p-r-primer GGACTACHVGGGTWTCTAAT \
  --p-trunc-len 120 \
  --p-min-length 100 \
  --p-max-length 400 \
  --o-reads ref-seqs.qza

qiime feature-classifier fit-classifier-naive-bayes \
  --i-reference-reads ref-seqs.qza \
  --i-reference-taxonomy ref-taxonomy.qza \
  --o-classifier gg-13-8-99-515-806-nb-classifier.qza

cp   gg-13-8-99-515-806-nb-classifier.qza ~/Desktop/EzMAP/src/db/gg-13-8-99-515-806-nb-classifier.qza

mkdir Taxonomy
mkdir Taxonomy/Greengenes
mkdir Taxonomy/Greengenes/qza/Deblur
mkdir Taxonomy/Greengenes/qzv/Deblur

time qiime feature-classifier classify-sklearn \
  --i-classifier ~/Desktop/EzMAP/src/db/gg-13-8-99-515-806-nb-classifier.qza \
  --i-reads Deblur/qza/single-end-rep-seqs-deblur.qza \
  --o-classification Taxonomy/Greengenes/qza/Deblur/single-end-greengenes-taxonomy-deblur.qza

time qiime metadata tabulate \
  --m-input-file Taxonomy/Greengenes/qza/Deblur/single-end-greengenes-taxonomy-deblur.qza \
  --o-visualization Taxonomy/Greengenes/qzv/Deblur/single-end-greengenes-taxonomy-deblur.qzv

echo "#### done ####"

