preprocessphyseq = reactive({
  get_phyloseq_data()
  })


remove = reactive ({

val1 = input$rem
val2= input$samp/100

pre_ps0 <- preprocessphyseq()
pre_ps5=NULL
pre_ps5 <- filter_taxa(pre_ps0, function(x) sum(x > val1) > (val2*length(x)), TRUE)
return(pre_ps5)

})



output$filtered_contents3 <- renderUI({
  output_phyloseq_print_html(get_phyloseq_data())
})
output$filtered_contents4 <- renderUI({
  output_phyloseq_print_html(remove())
})



 