echo "##### EzMAP ########"
echo "#### SILVA Taxonomy Classification #########"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

mkdir Taxonomy
mkdir Taxonomy/SILVA
mkdir Taxonomy/SILVA/qza
mkdir Taxonomy/SILVA/qzv

time qiime feature-classifier classify-sklearn \
  --i-classifier ~/Desktop/EzMAP/src/db/silva-classifier.qza \
  --i-reads qza/DADA2/single-end-rep-seqs-dada2.qza \
  --o-classification Taxonomy/SILVA/qza/single-end-greengenes-taxonomy.qza

time qiime metadata tabulate \
  --m-input-file Taxonomy/SILVA/qza/single-end-greengenes-taxonomy.qza \
  --o-visualization Taxonomy/SILVA/qzv/single-end-greengenes-taxonomy.qzv

echo "#### done ####"
