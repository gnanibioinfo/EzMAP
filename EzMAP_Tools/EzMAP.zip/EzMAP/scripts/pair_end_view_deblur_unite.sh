echo "##### EzMAP ########"
echo "### Taxanomy Classification ####"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Paired_End_Read_Analysis

qiime tools view Taxonomy/UNITE/qzv/Deblur/paired-end-UNITE-taxonomy-deblur.qzv