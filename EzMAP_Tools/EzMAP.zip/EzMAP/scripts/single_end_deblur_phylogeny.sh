echo "##### EzMAP ########"
echo "#### Deblur #########"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

mkdir Phylogenetic_tree
mkdir Phylogenetic_tree/Deblur
mkdir Phylogenetic_tree/Deblur/qza


time qiime phylogeny align-to-tree-mafft-fasttree \
  --i-sequences Deblur/qza/single-end-rep-seqs-deblur.qza \
  --o-alignment Phylogenetic_tree/Deblur/qza/single-end-aligned-rep-seqs-deblur.qza \
  --o-masked-alignment Phylogenetic_tree/Deblur/qza/single-end-masked-aligned-rep-seqs-deblur.qza \
  --o-tree Phylogenetic_tree/Deblur/qza/single-end-unrooted-tree-deblur.qza \
  --o-rooted-tree Phylogenetic_tree/Deblur/qza/single-end-rooted-tree-deblur.qza


echo "#### done ####"