echo "##### EzMAP ########"
echo "### Taxanomy Classification ####"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

qiime tools view Taxonomy/Greengenes/qzv/Deblur/single-end-greengenes-taxonomy-deblur.qzv