echo "##### EzMAP ########"
echo "### Taxanomy Classification ####"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Single_End_Read_Analysis

qiime tools view Taxonomy/Greengenes/qzv/DADA2/single-end-greengenes-taxonomy-dada2.qzv