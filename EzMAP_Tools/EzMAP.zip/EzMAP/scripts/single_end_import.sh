echo "##### EzMAP ########"
echo "#### Importing Single-end reads #####"


cp ~/Desktop/EzMAP_config.txt ~/Desktop/EzMAP/scripts/includes/EzMAP_config.txt



cd ~/Desktop/EzMAP_Analysis

DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

mkdir EzMAP_Single_End_Read_Analysis

infile="$DIR/includes/EzMAP_config.txt"

echo $infile

v2=$(head -n 1 $infile)

v3=$(sed -n '2{p;q;}' $infile)

v4=$(sed -n '3{p;q;}' $infile)

echo $v2
echo $v3
echo $v4 

time qiime tools import \
  --type 'SampleData[SequencesWithQuality]' \
  --input-path $v3 \
  --output-path EzMAP_Single_End_Read_Analysis/single-end-demux.qza \
  --input-format SingleEndFastqManifestPhred33V2



cd EzMAP_Single_End_Read_Analysis



time qiime demux summarize \
  --i-data single-end-demux.qza \
  --o-visualization single-end-demux.qzv


echo "#### Import success ####"


