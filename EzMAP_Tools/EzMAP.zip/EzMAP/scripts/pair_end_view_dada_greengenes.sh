echo "##### EzMAP ########"
echo "### Taxanomy Classification ####"

cd ~/Desktop/EzMAP_Analysis/EzMAP_Paired_End_Read_Analysis

qiime tools view Taxonomy/Greengenes/qzv/DADA2/paired-end-greengenes-taxonomy-dada2.qzv